
import Foundation

struct Journal {
    var name: String
    var mark: Int
}

extension Journal: CustomStringConvertible {
    var description : String {
        return "Name: \(name), Mark: \(mark)"
    }
}


struct queue <T> {
    private var elements: [T] = []
    
    public var isEmpty: Bool {
        return elements.count == 0
    }
    
    mutating func enqueue(element: T) {
        elements.append(element)
    }
    mutating func dequeue()->T {
        return elements.removeLast()
    }
    
    public var head: T? {
        if isEmpty {
            print("Элементы не найдены, массив пуст")
            return nil
        } else {
            print("Последний элемент - \(elements.last!)")
            return elements.last
        }
    }
    
    public var front: T? {
        if isEmpty {
            print("Элементы не найдены, массив пуст")
            return nil
        } else {
            print("Первый элемент \(elements.first!)")
            return elements.first
        }
    }
    
    func printMyQueue() {
        print(elements)
    }
}

extension queue {
    func myFilter(predicate:(T) -> Bool) -> [T] {
        var result = [T]()
        for i in elements {
            if predicate(i) {
                result.append(i)
            }
        }
        return result
    }
}

var peoples = queue<Journal>()
peoples.enqueue(element: .init(name: "Маша", mark: 4))
peoples.enqueue(element: .init(name: "Артём", mark: 5))
peoples.enqueue(element: .init(name: "Алиса", mark: 5))
peoples.enqueue(element: .init(name: "Алёна", mark: 3))
peoples.enqueue(element: .init(name: "Лёша", mark: 4))
peoples.enqueue(element: .init(name: "Андрей", mark: 3))
peoples.enqueue(element: .init(name: "Катя", mark: 4))
peoples.enqueue(element: .init(name: "Кирилл", mark: 3))

peoples.printMyQueue()
peoples.head
peoples.front

let honoursPeoples = peoples.myFilter(predicate: {$0.mark == 5})
print(honoursPeoples)


